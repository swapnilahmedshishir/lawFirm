# Purple Palette Challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/cheryl-codes/pen/VgPLOx](https://codepen.io/cheryl-codes/pen/VgPLOx).

